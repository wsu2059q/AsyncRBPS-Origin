moduleInfo = {
    "name": "AsyncServer",
    "version": "1.0.0",
    "description": "异步云湖适配器服务器模块",
    "author": "r1a, WSu2059",
    "dependencies": [],
}

from .Core import Main
