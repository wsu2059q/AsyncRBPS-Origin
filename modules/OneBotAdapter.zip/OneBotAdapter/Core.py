import asyncio
import json
from typing import Dict, List
import aiohttp

class Main:
    def __init__(self, sdk):
        self.sdk = sdk
        self.logger = sdk.logger
        self.ws_url = sdk.env.get("OneBotConnUrl", "ws://127.0.0.1:3001")
        self.conn_token = sdk.env.get("OneBotConnToken", None)
        self.connection: aiohttp.ClientWebSocketResponse = None
        self.session = None
        self.triggers: Dict[str, List[object]] = {}
        self.event_map = {
            "message": "message",
            "notice": "notice",
            "request": "request",
            "meta_event": "meta_event"
        }

    async def init_session(self):
        self.session = aiohttp.ClientSession()

    def AddTrigger(self, trigger: object):
        t_names = getattr(trigger, "on", None)
        if isinstance(t_names, list):
            for t_name in t_names:
                if t_name not in self.triggers:
                    self.triggers[t_name] = []
                self.triggers[t_name].append(trigger)
                self.logger.debug(f"成功注册OneBot触发器: 事件类型={t_name}, 触发器={trigger}")
        else:
            if t_names not in self.triggers:
                self.triggers[t_names] = []
            self.triggers[t_names].append(trigger)
            self.logger.debug(f"成功注册OneBot触发器: 事件类型={t_names}, 触发器={trigger}")

    async def connect(self):
        if self.session is None:
            await self.init_session()
        try:
            headers = {}
            if self.conn_token:
                headers["Authorization"] = f"Bearer {self.conn_token}"
            
            self.connection = await self.session.ws_connect(self.ws_url, headers=headers)
            self.logger.info(f"成功连接到OneBot服务器: {self.ws_url}")
            
            trigger_info = "\n".join(
                f"  事件类型: {event_type}, "
                f"触发器: {[f'{t.__module__}.{t.__class__.__name__}' for t in triggers]}"
                for event_type, triggers in self.triggers.items()
            )
            self.logger.debug(f"当前已注册的触发器列表:\n{trigger_info}")

            asyncio.create_task(self.listen())
        except Exception as e:
            self.logger.error(f"连接OneBot服务器失败: {str(e)}")

    async def listen(self):
        async for msg in self.connection:
            if msg.type == aiohttp.WSMsgType.TEXT:
                self.logger.debug(f"收到OneBot消息: {msg.data}")
                await self.handle_onebot(msg.data)
            elif msg.type == aiohttp.WSMsgType.CLOSED:
                self.logger.warning("OneBot连接已关闭")
                break
            elif msg.type == aiohttp.WSMsgType.ERROR:
                self.logger.error(f"WebSocket连接错误: {self.connection.exception()}")

    async def handle_onebot(self, message: str):
        try:
            data = json.loads(message)
            post_type = data.get("post_type")
            event_type = self.event_map.get(post_type, "unknown")
            
            if data.get("status") == "failed" and data.get("retcode") == 1403:
                msg = "OneBot连接验证失败: token验证失败"
                self.logger.error(msg)
                await self.shutdown(msg)
                return

            if event_type not in self.triggers or len(self.triggers[event_type]) == 0:
                self.logger.warning(f"没有找到 {event_type} 事件的触发器")
                return

            self.logger.debug(f"开始处理OneBot事件: {event_type} | 数据内容: {data}")
            for trigger in self.triggers[event_type]:
                self.logger.debug(f"调用触发器: {trigger}")
                await trigger.OnRecv(data)

        except json.JSONDecodeError:
            self.logger.error("OneBot消息解析失败: 无效的JSON格式")
        except Exception as e:
            self.logger.error(f"处理OneBot消息时出错: {str(e)}")

    async def send(self, content: dict):
        if self.connection and not self.connection.closed:
            try:
                self.logger.debug(f"发送到OneBot: {content}")
                await self.connection.send_str(json.dumps(content))
            except Exception as e:
                self.logger.error(f"发送消息到OneBot失败: {str(e)}")
    
    async def send_message(self, user_id: int, message: str, message_type: str = "private"):
        """
        发送消息到OneBot
        :param user_id: 接收者ID
        :param message: 消息内容
        :param message_type: 消息类型，private/group
        """
        if not self.connection or self.connection.closed:
            self.logger.error("OneBot连接未建立或已关闭")
            return False

        try:
            payload = {
                "action": "send_msg",
                "params": {
                    "message_type": message_type,
                    "user_id": user_id if message_type == "private" else None,
                    "group_id": user_id if message_type == "group" else None,
                    "message": message
                }
            }
            await self.connection.send_str(json.dumps(payload))
            self.logger.info(f"成功发送消息到 {message_type} {user_id}")
            return True
        except Exception as e:
            self.logger.error(f"发送消息失败: {str(e)}")
            return False

    async def Run(self):
        try:
            self.logger.info("正在启动OneBot适配器...")
            await self.connect()
            while True:
                await asyncio.sleep(1)
        except asyncio.CancelledError:
            await self.shutdown("OneBot适配器被取消")
        except (KeyboardInterrupt, SystemExit):
            await self.shutdown("OneBot适配器被终止")

    async def shutdown(self, msg):
        self.logger.info("正在关闭OneBot适配器...")
        if self.connection:
            await self.connection.close()
            self.logger.info("OneBot连接已关闭")
        if self.session:
            await self.session.close()
            self.logger.info("aiohttp会话已关闭")
        raise SystemExit(msg)
