moduleInfo = {
    "name": "OneBotNoticeHandler",
    "version": "1.0.0",
    "description": "OneBot适配模块 - 通知处理模块，该模块用于处理OneBot的通知",
    "author": "WSu2059",
    "dependencies": ["OneBotAdapter"],
}

from .Core import Main
