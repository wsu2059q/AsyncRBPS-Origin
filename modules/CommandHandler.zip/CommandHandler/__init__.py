moduleInfo = {
    "name": "CommandHandler",
    "version": "1.0.0",
    "description": "异步云湖适配器 - 命令消息处理模块",
    "author": "r1a, WSu2059",
    "dependencies": ["AsyncServer"],
}

from .Core import Main
