moduleInfo = {
    "name": "MessageHistory",
    "version": "1.0.0",
    "description": "异步云湖适配器 - 消息对话模块",
    "author": "r1a, WSu2059",
    "dependencies": ["MessageBase"],
}

from .Core import Main
