moduleInfo = {
    "name": "AIChatMessageStore",
    "version": "1.0.0",
    "description": "AI聊天模块 - 消息对话存储模块，该模块用于存储AI聊天模块的对话记录",
    "author": "WSu2059",
    "dependencies": [],
}

from .Core import Main
