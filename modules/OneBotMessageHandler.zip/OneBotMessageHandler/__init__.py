moduleInfo = {
    "name": "OneBotMessageHandler",
    "version": "1.0.0",
    "description": "OneBot协议消息处理模块",
    "author": "WSu2059",
    "dependencies": ["OneBotAdapter"],
}

from .Core import Main
