moduleInfo = {
    "name": "OneBotRequestHandler",
    "version": "1.0.0",
    "description": "OneBot适配模块 - 请求处理模块，该模块用于处理OneBot的请求",
    "author": "WSu2059",
    "dependencies": ["OneBotAdapter"],
}

from .Core import Main
