moduleInfo = {
    "name": "AIChat",
    "version": "1.0.0",
    "description": "AI聊天模块, 适配异步的OneBot及云湖触发器",
    "author": "WSu2059",
    "dependencies": [],
}

from .Core import Main