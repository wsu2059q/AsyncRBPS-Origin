moduleInfo = {
    "name": "NormalHandler",
    "version": "1.0.0",
    "description": "异步云湖适配器 - 普通消息处理模块",
    "author": "r1a, WSu2059",
    "dependencies": ["AsyncServer"],
}

from .Core import Main
