moduleInfo = {
    "name": "MessageEditor",
    "version": "1.0.0",
    "description": "异步云湖适配器 - 消息编辑模块",
    "author": "r1a, WSu2059",
    "dependencies": ["MessageBase"],
}

from .Core import Main
