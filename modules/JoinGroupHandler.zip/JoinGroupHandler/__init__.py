moduleInfo = {
    "name": "JoinGroupHandler",
    "version": "1.0.0",
    "description": "异步云湖适配器 - 加入群组事件处理模块",
    "author": "WSu2059",
    "dependencies": ["AsyncServer"],
}

from .Core import Main
